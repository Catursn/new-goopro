@extends('back.includes.master')

@section('title')
  Admin
@endsection

@section('content')
<!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
      <div class="container mt-5">
        <h3>SELAMAT DATANG DIHALAMAN ADMIN</h3>
        <p>PT. Jagad Kreatif Nusantara yang kemudian disebut Jagad Creative adalah perusahaan 
          yang bergerak di bidang jasa. Dibagi atas dua divisi utama yaitu, divisi desain & ilustrasi, 
          dan divisi komunikasi & teknologi informasi.
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit minus tenetur 
          cum recusandae esse eaque commodi optio ipsam obcaecati, quasi officia accusantium 
          voluptas! Repudiandae, pariatur nostrum. Minima ipsa enim architecto!
        </p>
      </div>
    </div>
  </div>
@endsection