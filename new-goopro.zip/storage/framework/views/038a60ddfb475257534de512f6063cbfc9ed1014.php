
<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <a href="#">Halaman Utama ></a>
        <a href="#" class="active">Login Admin</a>
    </div>
    <div class="bannerr">
        <img src="/images/register.png" alt="">
    </div>
    <div class="wadah">
        <div class="register">
            <div class="title">
                <h2>Lengkapi Formulir Registrasi <br> Keanggotaan GooPro</h2>
            </div>
            
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form method="POST" class="register-form" id="register-form" action="/admin/regstore">
            <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-40">
                        <div class="label">
                            <h5>Nama Lengkap *</h5>
                        </div>
                    </div>
                    <div class="col-60">
                        <div class="input">
                            <input type="text" name="nama" placeholder="Nama Lengkap">
                        </div>
                    </div>
                    <div class="col-40">
                        <div class="label">
                            <h5>Alamat Email *</h5>
                        </div>
                    </div>
                    <div class="col-60">
                        <div class="input">
                            <input type="email" name="email" placeholder="Nama@email.com">
                        </div>
                    </div>
                    <div class="col-40">
                        <div class="label">
                            <h5>No Telepon *</h5>
                        </div>
                    </div>
                    <div class="col-60">
                        <div class="input">
                            <input type="text" name="nomor_telepon" placeholder="08xxxxxxxxxx">
                        </div>
                    </div>
                    <div class="col-40">
                        <div class="label">
                            <h5>Password *</h5>
                        </div>
                    </div>
                    <div class="col-60">
                        <div class="input">
                            <input type="password" name="password">
                        </div>
                    </div>
                    <div class="col-40">
                        <div class="label">
                            <h5>Konfirmasi Password *</h5>
                        </div>
                    </div>
                    <div class="col-60">
                        <div class="input">
                            <input type="password" name="password_confirmation">
                        </div>
                        <div class="submit">
                            <input type="submit" name="signup" value="Daftar">
                            <!-- <a href="#">Daftar</a> -->
                        </div>
                        <div class="tnc">
                            <div class="row">
                                <div class="col-10">
                                    <input type="checkbox">
                                </div>
                                <div class="col-90">
                                    <h4>Ya, kirimkan saya informasi perumahan baru, data properti terkini dan penawaran dari partner Saya setuju untuk Rumah's Persyaratan Layanan 
                                    dan Kebijakan Privasi termasuk pengumpulan, penggunaan, dan pengungkapan informasi pribadi saya.</h4>
                                </div>
                            </div>
                            <h4>Dengan mendaftar, saya menyetujui Kebijakan Privasi</h4>
                            <h4>Sudah terdaftar ?<a href="/login"> Log In</a></h4> 
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/back/auth/register.blade.php ENDPATH**/ ?>