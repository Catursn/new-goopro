
<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <a href="#">Halaman Utama ></a>
        <a href="#">Berita ></a>
        <a href="#" class="active"><?php echo e($berita->judul); ?></a>
    </div>
    <div class="wadah">
        <div class="row">
            <div class="pagesberita">
                <img src="/images<?php echo e($berita->foto); ?>" alt="">
                <h1><?php echo e($berita->judul); ?></h1>
                <h6>Tanggal &nbsp;&nbsp;: <?php echo e(tanggal_indonesia($berita->tanggal, false)); ?></h6>
                <h6>Oleh &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : <?php echo e($berita->author); ?></h6>
                <h6>Kategori &nbsp;: <?php echo e($berita->kategori); ?></h6>
                <br>
                <?php echo $berita->deskripsi; ?>
                <div class="beritaterkait">
                    <h2>BERITA TERKAIT LAINNYA ...</h2>
                    <div class="row">
                        <?php $__currentLoopData = $terkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-50">
                            <img src="/images<?php echo e($ter->foto); ?>" alt="">
                            <h5><?php echo e($ter->judul); ?></h5>
                            <p><?php echo e(tanggal_indonesia($ter->tanggal, false)); ?></p>
                            <a href="<?php echo e($ter->slug); ?>">> Baca Selengkapnya</a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="col-50">
                            <img src="/images/berita2.png" alt="">
                            <h5>Apa & Kenapa Harus Investasi Properti?</h5>
                            <p>18 Desember 2022</p>
                            <a href="#">> Baca Selengkapnya</a>
                        </div>
                        <div class="col-50">
                            <img src="/images/berita3.png" alt="">
                            <h5>Kota Baru Parahyangan menggelar JABAR Property Expo 2022</h5>
                            <p>18 Desember 2022</p>
                            <a href="#">> Baca Selengkapnya</a>
                        </div>
                        <div class="col-50">
                            <img src="/images/berita4.png" alt="">
                            <h5>Kota Baru Parahyangan menggelar JABAR Property Expo 2022</h5>
                            <p>18 Desember 2022</p>
                            <a href="#">> Baca Selengkapnya</a>
                        </div> -->
                    </div>
                </div>
            </div>
            <div class="beritakanan">
                <div class="boxberita">
                    <div class="title">
                        BERITA PROPERTI TERKINI
                    </div>
                    <div class="isi">
                        <?php $__currentLoopData = $terkini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row list">
                            <img src="/images<?php echo e($ter->foto); ?>" alt="">
                            <div class="text">
                                <h4><?php echo e($ter->judul); ?></h4>
                                <p><?php echo e(tanggal_indonesia($ter->tanggal, false)); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="row list">
                            <img src="/images/terkini1.png" alt="">
                            <div class="text">
                                <h4>Kebutuhan Rumah Tapak Di Penyangga Jakarta Terus Meningkat </h4>
                                <p>10 Oktober 2022</p>
                            </div>
                        </div>
                        <div class="row list">
                            <img src="/images/terkini2.png" alt="">
                            <div class="text">
                                <h4>Ratusan Juta Harga per Rumah Di Indonesia mendapat diskon special </h4>
                                <p>7 Oktober 2022</p>
                            </div>
                        </div>
                        <div class="row list">
                            <img src="/images/terkini3.png" alt="">
                            <div class="text">
                                <h4>Jual dan jual Ribuan Rumah Saat ini. Segera! </h4>
                                <p>4 Oktober 2022</p>
                            </div>
                        </div>
                        <div class="row list">
                            <img src="/images/terkini4.png" alt="">
                            <div class="text">
                                <h4>Ribuan Genereasi Muda untuk beli Rumah Baru </h4>
                                <p>2 Oktober 2022</p>
                            </div>
                        </div>
                        <div class="row list">
                            <img src="/images/terkini5.png" alt="">
                            <div class="text">
                                <h4>Ribuan Rumah Di Sulawesi Tengah Dapat Program Bedah Rumah Permanen</h4>
                                <p>1 Oktober 2022</p>
                            </div>
                        </div> -->
                    </div>
                </div>
                <div class="boxberita">
                    <div class="title">
                        BERITA PROPERTI POPULER
                    </div>
                    <div class="isi">
                        <?php $__currentLoopData = $populer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list">
                            <h4><?php echo e($pop->judul); ?></h4>
                            <p><?php echo e(tanggal_indonesia($pop->tanggal, false)); ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="list">
                            <h4>Kebutuhan Rumah Tapak Di Penyangga Jakarta Terus Meningkat </h4>
                            <p>10 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Ratusan Juta Harga per Rumah Di Indonesia mendapat diskon special</h4>
                            <p>7 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Puluhan Rumah Di Jawa Barat Dapat Program Terbaik </h4>
                            <p>6 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Ribuan Rumah Di Sulawesi Tengah Dapat Program</h4>
                            <p>4 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Mau Apartemen Laku, Ini Strateginya  </h4>
                            <p>3 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Ribuan Genereasi Muda untuk beli Rumah Baru </h4>
                            <p>3 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Mau Apartemen laris manis, Ini cara jitunya!  </h4>
                            <p>2 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Ribuan Genereasi Muda menjadi Developer dgn modal nol. </h4>
                            <p>2 Oktober 2022</p>
                        </div>
                        <div class="list">
                            <h4>Mau Memulai Bisnis Properti, Mulai Aja!  </h4>
                            <p>1 Oktober 2022</p>
                        </div> -->
                    </div>
                </div>
                <div class="boxberita">
                    <div class="title">
                        KATEGORI BERITA PROPERTI
                    </div>
                    <div class="isi">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row list">
                            <h4><?php echo e($kat->kategori); ?></h4>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="row list">
                            <h4>Berita & Pasar Properti</h4>
                        </div>
                        <div class="row list">
                            <h4>Renovasi Properti</h4>
                        </div>
                        <div class="row list">
                            <h4>Informasi Keagenan</h4>
                        </div>
                        <div class="row list">
                            <h4>Tip & Trik Properti</h4>
                        </div>
                        <div class="row list">
                            <h4>Kisah Sukses Agen</h4>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/front/berita.blade.php ENDPATH**/ ?>