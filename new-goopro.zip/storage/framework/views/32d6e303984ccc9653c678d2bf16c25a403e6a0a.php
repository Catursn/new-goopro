<!DOCTYPE html>
<html>
    <?php echo $__env->make('front.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="content">
            <!-------------------------------
            ------------NAVBAR START---------
            -------------------------------->
            <?php echo $__env->make('front.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-------------------------------
            -------------NAVBAR END----------
            -------------------------------->
            <!-- <div class="container-fluid"> -->
                <?php echo $__env->yieldContent('main-content'); ?>
            <!-- </div> -->

            <!-------------------------------
            ------------FOOTER START---------
            -------------------------------->
            <?php echo $__env->make('front.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-------------------------------
            -------------FOOTER END----------
            -------------------------------->
        </div>
    </body>
</html><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/front/includes/master.blade.php ENDPATH**/ ?>