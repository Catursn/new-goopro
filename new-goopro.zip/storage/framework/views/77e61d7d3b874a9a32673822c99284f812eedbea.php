
<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <a href="#">Halaman Utama ></a>
        <a href="#" class="active">Lupa Kata Sandi</a>
    </div>
    <div class="bannerr">
        <img src="/images/register.png" alt="">
    </div>
    <div class="wadah">
        <div class="register">
            <div class="title">
                <h2>Lupa Kode Sandi</h2>
            </div>
            <div class="row">
                <div class="col-40">
                    <div class="label">
                        <h5>Alamar Nama Email *</h5>
                    </div>
                </div>
                <div class="col-60">
                    <div class="input">
                        <input type="email">
                    </div>
                    <div class="submit">
                        <a href="#">Kirim Kode Sandi</a>
                    </div>
                    <div class="tnc">
                        <h4>Sudah menjadi member GooPro ?<a href="#"> Klik masuk</a></h4> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/front/lupapassword.blade.php ENDPATH**/ ?>