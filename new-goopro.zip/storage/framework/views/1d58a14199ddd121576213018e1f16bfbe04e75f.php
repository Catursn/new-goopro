

<?php $__env->startSection('title'); ?>
  GANTI PASSWORD | DASHBOARD GOOPRO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<!-- ============================================================== -->
<!-- pageheader -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Ganti Password </h2>
            <!-- <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p> -->
            <div class="page-breadcrumb">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Setting</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Ganti Password</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- end pageheader -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        <form method="POST"action="/admin/<?php echo e($user->id); ?>/resetpassword" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?> <?php echo e(method_field('POST')); ?>

            <h5 class="card-header">Ganti Password</h5>
            <div class="card-body">
                <div class="form-group">
                    <label class="col-form-label">Password Lama</label>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="passwordlama">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-form-label">Password Baru</label>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="password">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-form-label">Konfirmasi Password Baru</label>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="password_confirmation">
                    </div>
                </div>
                <div style="float:right">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <!-- <a class="btn btn-primary">Submit</a> -->
                </div>
            </div> 
        </form>        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/back/gantipassword.blade.php ENDPATH**/ ?>