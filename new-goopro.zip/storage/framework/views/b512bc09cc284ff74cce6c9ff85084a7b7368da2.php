<!doctype html>
<html>
<?php echo $__env->make('back.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <?php echo $__env->make('back.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('back.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container-fluid dashboard-content">
                <?php echo $__env->make('back.includes.notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('main-content'); ?>
                </div>
                <?php echo $__env->make('back.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- ============================================================== -->
                <!-- end main wrapper -->
                <!-- ============================================================== -->
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <script src="/backend/js/jquery/jquery-3.3.1.min.js"></script>
        <script src="/backend/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="/backend/js/slimscroll/jquery.slimscroll.js"></script>
        <script src="/backend/js/main-js.js"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
 </html><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/back/includes/master.blade.php ENDPATH**/ ?>