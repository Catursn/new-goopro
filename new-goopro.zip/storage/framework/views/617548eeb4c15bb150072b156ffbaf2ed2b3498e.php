

<?php $__env->startSection('title'); ?>
  EDIT <?php echo e($hunian->hunian); ?> | DASHBOARD GOOPRO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<!-- ============================================================== -->
<!-- pageheader -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Edit <?php echo e($hunian->hunian); ?> </h2>
            <!-- <p class="pageheader-text">Proin placerat ante duiullam scelerisque a velit ac porta, fusce sit amet vestibulum mi. Morbi lobortis pulvinar quam.</p> -->
            <div class="page-breadcrumb">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Kategori Hunian</a></li>
                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Edit</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($hunian->hunian); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- end pageheader -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="card">
            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        <form class="form-horizontal" data-toggle="validator" method="POST" action="<?php echo e(route('kategorihunian.update',$hunian->id_hunian)); ?>" enctype="multipart/form-data" >
            <?php echo e(csrf_field()); ?> <?php echo e(method_field('PATCH')); ?>

            <h5 class="card-header">Edit Kategori Hunian</h5>
            <div class="card-body">
                <div class="form-group">
                    <label for="inputText3" class="col-form-label">Kategori</label>
                    <input id="inputText3" type="text" class="form-control" name="hunian" value="<?php echo e($hunian->hunian); ?>" required>
                </div>
                <div class="form-group">
                    <label class="col-form-label">Icon</label>
                    <div class="input-group mb-3">
                        <input type="file" class="form-control" name="icon">
                    </div>
                    <h2>Foto Icon Lama</h2>
                    <img src="/images<?php echo e($hunian->icon); ?>" alt="">
                </div>    
                <div class="form-group">
                    <label for="status">Status <span class="text-danger">*</span></label>
                    <select name="status" class="form-control" required>
                        <option value="">--Pilih Status--</option required>
                        <option value="aktif" <?php echo e((($hunian->status=='aktif')? 'selected' : '')); ?>>Aktif</option>
                        <option value="nonaktif" <?php echo e((($hunian->status=='nonaktif')? 'selected' : '')); ?>>Nonaktif</option>
                    </select>
                </div>
                <div style="float:right">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>  
            </form>        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\DATA CATUR\GIT\new-goopro\resources\views/back/kategorihunian/edit.blade.php ENDPATH**/ ?>